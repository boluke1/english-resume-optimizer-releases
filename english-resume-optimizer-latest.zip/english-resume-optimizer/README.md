# 英文简历优化专家 · Elena

按 MEM/MBA 申请与海外求职标准，诊断并重写英文简历：结构梳理、成果型要点、用词精确、一页 A4 交付。

## 类型

Agent 型（单个 AI 专家）

## 功能

- **读者视角诊断**：先判断投递目标是职业发展还是学术申请，按两套考察清单逐项核对，输出分优先级的诊断表（必须改 / 建议改 / 可选）。
- **板块重构**：按个人信息、教育背景、工作经历、发表、社会任职、语言与计算机能力六大板块搭骨架；明确指出婚育、宗教、健康、出生地、年龄、修读课程、自我评价等不该写进英文简历的内容。
- **成果型要点重写**：把"负责某某工作"改写成满足 when / where / with whom / did what / result 五要素的成果句，一条一个意思，用数据代替形容词。
- **语言规范校对**：修口语化表达、词性误用、时态混用、平行结构断裂；提供可直接复用的 AI 校对提示词。
- **MEM / MBA 适配**：把工程与管理的复合背景、商业成果、领导力轨迹按目标项目重新排序；为最强要点补 60 秒英文口述版与预判追问。
- **模板与排版**：区分欧版与美版模板规则，给出一页 A4 版面参数与 ATS 友好检查。

### 增强能力（v1.1 新增，均在课件规则之内）

- **五维评分卡**：读者匹配度 / 结构合规度 / 成果强度 / 语言规范度 / 面试可支撑度，各 20 分。分数只用于显示短板权重，不替代逐条问题清单。
- **JD / 项目要求对齐**：把岗位描述拆成"要求 → 对应经历 → 覆盖程度"映射表，标出 gap 并给补强正路；禁止靠堆关键词补匹配度。
- **回译校验**：把改写后的英文回译成中文比对原意，专抓夸大、偏移、丢限定三类偏差。
- **逐句精修**：只动指定行，输出"原句 / 改句 / 改动点"，并单列"未改动部分仍存在的问题"。
- **多版本管理**：母版 + 按投递目标裁剪的若干版本，同一事实全版本口径一致，附差异记录。
- **五种工作模式**：全篇重写 / 逐句精修 / 只出诊断 / 单条要点打磨 / 回译校验。


## 使用示例

- 帮我按 MEM 申请要求优化这份英文简历：先诊断问题，再给出改后全文。
- 把这段中文工作经历改写成英文简历里的成果型要点，带上数据。
- 帮我检查英文简历的语法、时态和用词，然后按面试官视角逐条追问。

## 目录结构

```
english-resume-optimizer/
├── .codebuddy-plugin/plugin.json
├── agents/english-resume-optimizer.md         # 主 Agent 定义
├── skills/english-resume-writing/
│   ├── SKILL.md                               # 五步执行流程
│   └── references/
│       ├── sections-and-elements.md           # 板块与要素清单
│       ├── reader-perspective.md              # 读者视角与失败简历分析
│       ├── seven-golden-practices.md          # 七个黄金实践
│       ├── highlight-writing.md               # 成果型要点改写
│       ├── language-and-proofreading.md       # 语言规范与四层校对
│       ├── mem-mba-playbook.md                # MEM/MBA 适配与面试接口
│       ├── templates.md                       # 欧版/美版模板与版面
│       ├── scoring-and-alignment.md           # 五维评分卡与 JD 对齐
│       └── editing-modes.md                   # 五种工作模式与版本管理
└── avatars/expert.png
```

方法论来源：《Resume & Interview Workshop》（Dr. Hongyan, 2026）教学框架，并经 MEM 课程要求与 MBA 英语面试场景适配。

## 头像

头像已生成在 `avatars/expert.png`（512×512，约 448KB）。如需替换：
- 格式：PNG（推荐）或 JPG
- 尺寸：512×512 px
- 大小：单张不超过 500KB

## 安装

专家包位置：

```
/Users/cuihang/.workbuddy/plugins/marketplaces/my-experts/plugins/english-resume-optimizer/
```

注册使其可见：

```bash
python3 scripts/register_expert.py <expert-dir>
```

## 打包分享

```bash
python3 scripts/package_expert.py <expert-dir>
```
