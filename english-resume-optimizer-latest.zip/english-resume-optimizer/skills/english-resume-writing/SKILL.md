---
name: english-resume-writing
description: Methodology and checklists for writing, diagnosing, scoring and proofreading English resumes (Resume / CV) for MEM/MBA applications and international job search. Use when producing a resume diagnostic or scorecard, aligning resume content with a job description, rewriting bullet points into achievement statements, line-editing specific lines, verifying rewrites by back-translation, choosing EU/US templates, or proofreading grammar, tense and word choice.
---

# 英文简历写作方法

本技能是一套可执行的简历诊断与重写方法，源自《Resume & Interview Workshop》教学框架。执行顺序固定：**定场景 → 诊断 → 目标对齐 → 重写 → 校对 → 面试对齐 → 交付**。不要跳步，不要一上手就给成品。

> **规则层级**：课件规则（一页 A4、五要素成果句、七类必删内容、书面文体、只写能自信谈论的内容）是硬底线。评分卡、JD 对齐、模板美化等手段只能在此基础上增效，冲突时一律按课件规则执行。

## 何时读取哪个参考文件

| 任务 | 读取 |
|------|------|
| 判断"该写什么/不该写什么"、板块搭建、页数与篇幅 | `references/sections-and-elements.md` |
| 从读者/招生官视角做诊断、常见失败简历分析 | `references/reader-perspective.md` |
| 七个黄金实践逐条自查 | `references/seven-golden-practices.md` |
| 把职责句改写成成果句、动词与量化 | `references/highlight-writing.md` |
| 语法/时态/平行结构/口语化/用词精确性 | `references/language-and-proofreading.md` |
| MEM 申请与 MBA 英语面试的适配 | `references/mem-mba-playbook.md` |
| 欧版/美版模板与一页 A4 版面参数 | `references/templates.md` |
| 五维评分卡、JD 关键词映射、gap 处理 | `references/scoring-and-alignment.md` |
| 五种工作模式（重写/精修/只诊断/单条/回译）、版本管理 | `references/editing-modes.md` |

## 执行流程

### Step 1 定场景
确认四件事：目标（MEM/MBA 申请 / 海外求职 / 学术 CV）、投递地区（欧版/美版）、材料形态（中文原稿 / 旧英文简历 / 零散经历）、**工作模式**——全篇重写 / 逐句精修 / 只出诊断 / 单条要点打磨 / 回译校验。模式见 `editing-modes.md`，未确认模式前不擅自整篇重写。

### Step 2 诊断（不改写）
按 `reader-perspective.md` 的考察清单逐项核对，输出诊断表：

| # | 位置 | 问题 | 依据 | 影响 | 优先级 |
|---|------|------|------|------|--------|
| 1 | Working Experience 第 2 条 | 只有职责没有结果 | 缺 when/result，无法回答"做成了什么" | 招生官无法判断能力层级 | 必须改 |

优先级只用三档：`必须改` / `建议改` / `可选`。诊断阶段禁止夹带改写成品，避免用户只看到结论看不到问题。

诊断表之后附**五维评分卡**（读者匹配度 / 结构合规度 / 成果强度 / 语言规范度 / 面试可支撑度，各 20 分），每维注明扣分依据。打分见 `scoring-and-alignment.md`；分数不得代替问题清单。

### Step 2.5 目标对齐
有明确 JD 或项目要求时，做"要求 → 对应经历 → 覆盖程度（充分/部分/缺失）"三列映射表，标出 `gap` 并给补强正路。无明确目标时用课件两套考察清单替代，并说明这是通用诊断。**禁止用关键词堆砌补 gap。**

### Step 3 重写
按 `highlight-writing.md` 的方法逐条改写，每条满足"一个意思 + 动词开头 + 可量化结果 + 可被追问"。改完输出两份材料：
1. 英文全文（可直接复制投递）
2. 前后对照表：`Before | After | 改动理由`

改写后做一次**回译校验**：把新写的句子回译成中文，与原意比对，抓 `夸大` / `偏移` / `丢限定` 三类偏差，有偏差即退回重写。详见 `editing-modes.md`。

### Step 4 校对
按 `language-and-proofreading.md` 的四层检查过一遍：文体（书面 vs 口语）、拼写、语法（词性/时态/平行结构）、格式（日期、数字、姓名大小写）。列出所有"需用户确认"的空白项。

### Step 5 面试对齐
对最强的 3–5 条写成 60 秒英文口述版；每条预判 2 个追问。这一步是简历与 MBA 英语面试的接口，不要省略。凡是"改了但讲不出来"的句子，倒回 Step 3 重写。

### Step 6 交付
按模式给交付物：全篇重写交完整稿；逐句精修交三列修改表 + "未改动部分仍存在的问题"；只出诊断交诊断表 + 评分卡。多版本场景（母版 + 裁剪版）附差异说明，保证同一事实口径一致。见 `editing-modes.md`。

## 硬性约束

1. **课件规则优先**：一页 A4、五要素成果句、七类必删内容、书面文体、只写能自信谈论的内容——这几条不得为任何"优化技巧"让路。冲突时按课件规则执行，并说明为什么没采纳该技巧。
2. 一页 A4 为默认上限（求职、项目申请）；学术 CV 有大量发表时才扩展，并说明理由。
3. 不虚构任何数字、奖项、职称、时间。缺信息写占位符 `[confirm …]` 并向用户索取。
4. 不把自我评价、Personal Statement 塞进简历正文。
5. 敏感个人信息（政治面貌、国籍、照片、婚育、年龄、宗教、健康、出生地、修读课程）默认不写；用户坚持时提示地区差异与风险。
6. 每条要点不超过两行；同一板块要点数量控制在 3–5 条，超出即意味着需要取舍。
7. 英文正文不夹中文；诊断与解释用中文。
8. 用词精确优先于用词华丽；不确定的词先查同义词辨析，不用"看起来高级"的词。
9. 关键词只为"发现已有但没写出来的经历"服务，不为补齐岗位匹配度而添加未做过的内容。

## 输出模板（重写交付）

```
## 一、诊断结论
（表格：必须改 / 建议改 / 可选）

## 二、五维评分卡
| 维度 | 得分 | 扣分依据 |
（读者匹配度 / 结构合规度 / 成果强度 / 语言规范度 / 面试可支撑度，各 20 分）

## 三、目标对齐（有 JD 时）
| 要求 | 对应经历 | 覆盖程度 | 处理 |
（gap 项写明缺什么、怎么补，不写"建议加关键词"）

## 四、改写要点对照
| Before | After | 改动理由 |

## 五、英文全文（可直接投递）
（按板块顺序，一页 A4 容量）

## 六、待确认信息
- [ ] 2023 年项目的营收数字
- [ ] 竞赛全称与年份

## 七、面试展开（60 秒口述版）
1. 要点 → 口述稿 → 预判追问
```
