# 简历板块与要素清单

## 一、什么时候需要简历

- **Resume = résumé**（美式，求职用，1 页为主）
- **CV = curriculum vitae**（学术/欧洲体系，可多页，含发表）
- 两大类用途：
  1. **For career development** — 求职、跳槽、内部晋升
  2. **For academic purposes** — 学位项目申请（MEM / MBA / 硕博）、访问学者、发表配套材料

用途决定板块顺序与取舍，不是先有模板再往里塞内容。

## 二、标准板块（Sections）

| 顺序 | 板块 | 说明 |
|------|------|------|
| 1 | Personal information | 姓名、性别、出生日期、地址、电话、手机、邮箱 |
| 2 | Educational Background | 学位、专业、院系、学校、时间 |
| 3 | Working Experience | 全职、兼职、实习、暑期工 |
| 4 | Publications | 论文、专著、专利（学术用途必备） |
| 5 | Affiliations | 学会、协会、社会任职 |
| 6 | Computer & Language skills | 语言等级、软件与编程能力 |

项目经历（Project Experience）作为 Working Experience 的下级块或并列块，视经历多少决定。

## 三、必须排除的内容

以下内容不写进英文简历（中文简历里常见，英文语境里是减分项）：

- Marital status（婚姻状况）
- Religious belief（宗教信仰）
- Health condition（健康状况）
- Courses taken（修读课程）——课程名不等于能力，用项目与成果替代
- Birthplace（出生地）
- Age（年龄）
- Self evaluation / Personal statement（自我评价、个人陈述）——属于另一类文档，不进简历

理由：这些信息与岗位胜任力无关，且在多数国家涉及招聘歧视风险；写上去会稀释有效信息。

## 四、可写可不写（voluntarily）

以下四项属于"自愿提供"，取决于目标地区与个人策略：

| 项目 | 判断要点 |
|------|----------|
| Political status（政治面貌） | 海外投递默认不写；境内体制内岗位可写 |
| Citizenship（国籍） | 需要工作许可说明时写；否则可不写 |
| Photo（照片） | 欧版部分国家习惯附照；美版与英国主流不附照，附照反而可能被视为不专业 |
| Hobbies（爱好） | 只在能体现岗位相关特质时写（见下） |

## 五、个人信息的关键要素

姓名、性别、出生日期、地址、电话、手机、邮箱，逐项检查格式：

```
Name:        ZHANG Hongyan (David)        ← 姓全大写，英文名括号标注
Gender:      Male / Female
Birth Date:  Oct. 1980                    ← 月在前，用缩写加句点
Address:     No.5 Yiheyuan Road, Haidian District, Beijing, P.R.China 100871
Tel.:        +8610 6275 3456              ← 座机带国家码与区号
Cell./M.P.:  +86 138 1100 0011            ← 手机带国家码，分段易读
E-mail:      drzhy@pku.edu.cn             ← 用姓名拼音，不用昵称
```

要点：
- 姓（family name）全大写，避免招生官混淆哪个是姓。
- 有常用英文名时用括号附上，面试时对方好称呼。
- 地址由小到大，末尾带邮编；投递海外时国家名写 P.R.China。
- 邮箱用 `姓名拼音@` 或学校/公司邮箱，不用 `cool_boy88@` 这类。

## 六、教育背景的写法

```
Educational Background:
MEM Candidate in Innovation Engineering Management,
School of Software & Microelectronics, Peking University          (2025–2027)

B.A. in English Education                                        (20xx–20xx)
B.E. in Electronic Engineering
B.S. in Computer Science
```

要点：
- 学位写法固定：`M.S. / M.Eng. / MEM / MBA / B.A. / B.S. / B.E.`，后接 `in + 专业`。
- 在读用 `Candidate`（MEM Candidate），已毕业直接写学位名。
- 学校与院系写全称，不用缩写（除非该缩写全球公认）。
- **不写"修读课程"清单**；课程相关性通过项目经历、研究方向体现。

## 七、职业/工作经历的写法

涵盖四类经历，全部归入 Working Experience：

- Part-time job（兼职）
- Internship（实习）
- Summer job（暑期工作）
- 全职经历

每条经历的固定结构：

```
2015.06–2016.05  Product Partner & Co-Founder
                 Hangzhou Mao Gan Technology Co., Ltd.

– Responsible for the product team, completed the design and operation of
  multiple applications including Internet Finance and Smart HR.
– Responsible for customer maintenance, coordination, and daily operation
  management of the company.
```

原则：**Responsibility + Achievement**。只写职责（Responsibility）是及格线，必须补上成果（Achievement）——做了什么、做到什么程度、带来什么结果。写法细节见 `highlight-writing.md`。

## 八、爱好怎么写才不算浪费空间

先列出全部爱好，再判断"对雇主意味着什么"，最后决定"有利还是不利"：

| 常见爱好 | 传递的信号 | 判断 |
|----------|------------|------|
| Basketball / Football / Badminton / Ping Pang | 团队协作、竞争意识 | 有利，但需有持续投入的证据 |
| Hiking / Camping / Marathon / Jogging | 毅力、目标管理、抗压 | 有利，马拉松类有完赛成绩更好 |
| Games（电子游戏） | 可能被读成时间管理风险 | 一般不写，除非是电竞相关岗位 |
| Novel / Music | 审美与表达、专注力 | 中性，仅在空间充裕时写 |

规则：**爱好只在能支撑岗位特质时写**，且尽量带证据（年限、级别、成绩），一句话写完，不占独立板块。

## 九、语言与计算机能力

语言能力用固定档位标注，不用"良好/一般"这类模糊词：

```
Language Skills:
– English: Bilingual / Fluent / Working proficiency / Survival
– Chinese: Native
– French:  Second foreign language

Computer Skills:
– Microsoft Office; Spreadsheet
– Python (20 months), C++ (100K lines)
– Trados
```

要点：
- 档位顺序：Native > Bilingual > Fluent > Working > Survival，按真实水平选，不越档。
- 编程能力**带量化**：`Python (20 months)`、`C++ (100K lines)` 比"熟悉 Python"可信。
- 工具名写行业通用名（Trados、SPSS、Figma），不写"熟练使用办公软件"。
