# 模板选择与一页 A4 排版

## 一、欧版 vs 美版

| 维度 | 欧版（European） | 美版（US） |
|------|------------------|------------|
| 篇幅 | 1–2 页常见 | 严格 1 页 |
| 照片 | 部分国家习惯附照（德、法、西等） | 不附照 |
| 个人信息 | 出生日期、国籍、地址较完整 | 只留姓名、电话、邮箱、城市（LinkedIn 可选） |
| 婚育/年龄 | 偶见，但趋势在减少 | 一律不写 |
| 内容重心 | 教育与经历的完整性、资质证书 | 成果与量化，动词强度高 |
| 排版 | 稍紧凑，可用细线分区 | 留白多，单栏为主 |
| CV 含义 | 等同简历，1–2 页 | CV 特指学术履历，可多页 |

选择规则：
1. 投递地区以**岗位所在国**为准，不是学校所在国。
2. 同一份简历不混用两套规则（例如美版格式 + 照片 = 最差组合）。
3. 申请欧洲项目（含英国以外的欧陆院校）可用欧版；申请美国/英国院校与美资企业用美版。
4. 中国境内投递英文简历，默认用美版（无照片、无出生日期）。

## 二、一页 A4 的版面参数

| 项目 | 建议值 |
|------|--------|
| 纸张 | A4（申请欧洲/亚洲）或 Letter（申请美国） |
| 页边距 | 上下 1.8–2.0 cm，左右 2.0 cm |
| 正文字号 | 10–10.5 pt |
| 板块标题 | 11–12 pt，加粗，全大写或首字母大写，可加细横线 |
| 行距 | 1.0–1.15，段前 0 段后 2–4 pt |
| 字体 | Calibri / Arial（现代）或 Times New Roman（传统学术） |
| 姓名 | 14–16 pt，加粗，居中或左对齐 |
| 要点符号 | `–` 或 `•`，最多两级缩进 |
| 板块数 | 4–6 个，顺序按目标场景调整 |
| 每个板块要点数 | 3–5 条，超过即需取舍 |

## 三、两种常用版式骨架

### 版式 A：时间倒序型（求职、MBA 常用）

```
ZHANG Hongyan (David)
+86 138 1100 0011 | drzhy@pku.edu.cn | Beijing, China

EDUCATION
MEM Candidate in Innovation Engineering Management,
School of Software & Microelectronics, Peking University        2025–2027
B.E. in Electronic Engineering, [University]                    2004–2008

PROFESSIONAL EXPERIENCE
[Company], [Title]                                              2018–Present
– [Achievement bullet, verb-first, quantified]
– [Achievement bullet]
– [Achievement bullet]

[Company], [Title]                                              2015–2018
– [...]

SKILLS
Languages: English (Fluent), Chinese (Native)
Technical: Python, C++, Microsoft Office, Trados
```

### 版式 B：能力聚合型（转型申请、经历零散时用）

```
NAME
Contact line

PROFILE (2 lines, optional — only if the narrative needs framing)

CORE COMPETENCIES
– Engineering project delivery  – Cross-functional team leadership
– Data-driven decision making   – Vendor & stakeholder management

EXPERIENCE  (reverse chronological, same as A)

EDUCATION
```

注意：`PROFILE` 段不是自我评价，只写"身份 + 年限 + 一句定位"，例如 `Engineering manager with 12 years in medical devices, moving from regional sales leadership into technology-driven operations.` 不写"我是一个有责任心的人"。

## 四、板块顺序的三种调法

| 情形 | 顺序 |
|------|------|
| 工作经历强、学历一般 | Experience → Education → Skills |
| 学历强、经历弱（应届/在读申请） | Education → Projects → Experience → Skills |
| 学术申请（有发表） | Education → Publications → Research Experience → Affiliations → Skills |

## 五、可用工具与导出

- 排版：Word / Pages / LaTeX（`moderncv`、`awesome-cv`）/ Canva（慎用复杂图形模板）。
- 导出：**必须导 PDF**，文件名 `Name_Resume_MEM2027.pdf` 或 `Name_CV.pdf`；不要发 .docx（字体与版式会跑）。
- 检查：导出后逐页看——是否溢出到第 2 页、最后一行是否被裁、要点符号是否对齐。
- 投递系统（ATS）友好：单栏、无文本框、无图表、标准板块名（EDUCATION / EXPERIENCE / SKILLS）。图片式简历在 ATS 里等于空白。

## 六、模板自查清单

- [ ] 与投递地区匹配（欧版/美版），不混用
- [ ] 一页装完，无孤行（orphan line）
- [ ] 板块标题统一大小写风格
- [ ] 日期格式全文统一，区间用 en dash
- [ ] 要点符号与缩进一致，最多两级
- [ ] 无照片（美版）、无出生日期（美版）、无婚育信息
- [ ] 单栏、无文本框，能被 ATS 正确解析
- [ ] 导出 PDF 后版式未变
