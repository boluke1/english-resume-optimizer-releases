# 七个黄金实践

逐条自查，每条给出"合格标准"与"常见不合格"。

> 说明：原始课程材料在"Seven Golden Practices"标题下展开了第 1–6 条。第 7 条为收口原则（一页之内完成表达），由第 1 条"仅限一页 A4"提炼而来，用于统一前面六条的自查尺度。

## 1. 中文简历先复查，再做英文版（Neat Chinese Version）

英文版的问题往往不是英文，而是中文原稿就没想清楚。

- 思路清晰，避免信息重复：同一个成就在两个板块各说一遍，是典型的信息重复。
- 语言简洁：删掉"具有一定的…能力""致力于…"这类无信息量的表述。
- **仅限一页 A4**（求职、项目申请）；学术 CV 有大量发表时按需扩展。

合格标准：把中文原稿压到一页，且每一句都不可删——做不到就先瘦身，不要指望翻译时自动变干净。

## 2. 英文模板慎选（Proper Template）

- **欧版（European）**：部分国家习惯含照片、出生日期、国籍，个人信息较完整，排版偏紧凑。
- **美版（US）**：一页、无照片、无出生日期与婚育信息，强调成果与量化，留白较多。

合格标准：模板与投递地区匹配；不要用花哨的双栏时间轴模板去投美版岗位。细节见 `templates.md`。

## 3. 他人视角判定（Mock Interview）

- 用**面试者视角**读自己的简历，而不是作者视角。
- 小组内互查，按"面试者 / 被面试者 / 观察者"三角色做模拟面试。
- 观察者记录"简历写了但答不上来"的条目。

合格标准：简历上每一条都能撑住 60 秒英文口述 + 2 个追问。

## 4. 语言使用要规范（Proper Language）

- **使用正规书面文体，避免口语化、非正式化**：

| 不合格 | 合格 |
|--------|------|
| Got about 1 mn revenue | Generated approximately USD 1 million in revenue |
| I've won three champions in the contest. | Won three championships in [contest name], [year]. |

  两个典型错误：`Got` 是口语动词；`champions` 应为 `championships`（冠军头衔 ≠ 冠军人数）；`I've won` 这类缩写与完成时在简历条目里不合文体。

- **拼写正确**：定稿前用 AI 工具校对，提示词直接可复用：
  > Please help me proofread the following paragraph. Fix spelling, punctuation and grammar only. Do not change my meaning or add content. List every change you made with the reason.

- **语法正确**，三个高频点：
  1. **词性**：注意常见词的名词与动词形式区别（`analysis / analyze`、`management / manage`、`growth / grow`）。
  2. **时态**：一般过去时（已完成的工作）、现在完成时（持续影响）、现在完成进行时（仍在持续）；在任职位用一般现在时。
  3. **平行结构**：`and / or` 连接的词或词组形式必须一致（`designing, building and operating` ✅；`designing, building and operation` ❌）。

合格标准：全文无缩写（`I've`、`don't`、`it's`），无口语动词（`got`、`do`、`make` 泛用），时态在一条经历内统一。

## 5. 重点优势要突出（Competitive Advantage）

- **每一点只讲一个意思**。一条要点塞进三件事，读者一件都记不住。
- **主要成就须能回答**：when（何时）、where（何地/何项目）、with whom（与谁/什么团队）、did what（做了什么）、result（结果如何）。
- **使用数据而不是形容词、副词**。"显著提升"→"提升 32%"；"大幅降低成本"→"年度成本下降 RMB 1.2 million"。
- **只包含自己可以自信谈论的话题**。写上去就要能应对追问，否则是给自己挖坑。

合格标准：随机抽一条要点，你能在 60 秒内把它展开成 when/where/with whom/did what/result 五要素齐全的口述。

## 6. 选词造句要精确（Word Choices）

- 收集并学习 **3 篇与自己经历相近的优秀简历**，逐句拆解动词与句式——这是提升用词最快的路径。
- 用**同义词辨析词典**查词，而不是用翻译工具替换。推荐：《现代英语同义词、近义词辨析词典》（林德金）。
- 典型需要辨析的词组：`lead / manage / direct`、`develop / build / create`、`improve / enhance / optimize`、`responsible for / accountable for`、`achieve / attain / accomplish`。

合格标准：每个动词都能说出它与你实际动作的贴合点；不用"看起来高级"但语义不准的词。

## 7. 一页之内完成表达（One Page, Complete Story）

七个实践的前六条都在做减法，第七条是收口：在一页之内把"我是谁、我做成过什么、我能带来什么"说完。

合格标准：删掉任何一条要点都会造成信息损失；反之，任何一条要点都不是"可有可无的背景介绍"。
