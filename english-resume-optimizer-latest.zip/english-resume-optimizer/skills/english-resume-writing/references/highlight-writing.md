# 成果型要点写作（Highlight Writing）

简历里 80% 的差距在这一步拉开：同样的经历，写成"职责"还是写成"成果"，读者感受完全不同。

## 一、五要素公式

每条要点必须能回答五个问题：

| 要素 | 问题 | 示例片段 |
|------|------|----------|
| When | 什么时候 | `In Q3 2023` / `over 18 months` |
| Where | 在哪 / 哪个项目 | `for the Beijing flagship store` / `in the MEM capstone project` |
| With whom | 与谁 / 什么规模团队 | `leading a cross-functional team of 8` / `with two vendors` |
| Did what | 做了什么动作 | `redesigned the onboarding flow` |
| Result | 结果多少 | `cutting drop-off from 46% to 21%` |

一条要点不必把五个词都写出来，但读者必须能一次读到这五层信息。缺 Result 的要点一律判为不合格。

## 二、改写四步法

1. **抽事实**：从中文原稿里只抽事实（时间、动作、对象、数字），先不管英文。
2. **定主句**：选一个精确动词做开头，主句只承载一个意思。
3. **补结果**：没数字就去找数字（人数、金额、比例、时长、排名、覆盖范围）；确实没有，用可验证的替代（上线/交付/被采纳/被引用）。
4. **压行数**：每条不超过两行，删掉修饰性副词，保留数据。

## 三、前后对照范例

### 例 1：职责句 → 成果句

Before:
> Responsible for the product team, completed the design and operation of multiple applications including Internet Finance and Smart HR.

After:
> Led a 6-person product team to launch two B2B applications (Internet Finance, Smart HR) within 9 months, reaching 12,000 registered enterprise users and RMB 3.2 million in first-year revenue.

改动理由：`Responsible for` → `Led`（明确角色强度）；`multiple applications` → 具体数量与名称；补上团队规模、周期、用户量、收入——五要素齐全。

### 例 2：口语化 + 词性错误

Before:
> Got about 1 mn revenue and I've won three champions in the contest.

After:
> Generated approximately USD 1 million in revenue in 2022; won three championships in the National Business Plan Competition (2021–2022).

改动理由：`Got` → `Generated`（书面）；`mn` → `USD 1 million`（币种明确）；`champions` → `championships`（头衔而非人）；拆成两条并列要点，删除缩写 `I've`。

### 例 3：形容词堆砌 → 数据

Before:
> Had a very strong market sense and rich industry experience, greatly improved sales performance.

After:
> Grew regional sales from RMB 18 million to RMB 47 million in three years (+161%) by rebuilding the distributor network across 6 provinces.

改动理由：删除 `very strong / rich / greatly`（不可验证）；用一个可核对的增长率替代；补上手段（重建经销网络）让因果成立。

### 例 4：介绍公司 → 介绍自己

Before:
> XX Group is an international medical health group integrating R&D, manufacturing, marketing and medical services, with 11 national high-tech subsidiaries.

After:
> (删除，或压缩为括号短语) `(a medical device group with 11 national high-tech subsidiaries)`

改动理由：读者要判断的是候选人，不是公司。公司背景只在"没有它读者看不懂你的层级"时以半行括号保留。

### 例 5：头衔罗列 → 晋升与贡献

Before:
> 历任北京区总经理、北方大区总经理、客服中心总经理、营销中心副总经理、两家公司董事长。

After:
> Promoted four times in 14 years (Regional GM, Beijing → Regional GM, North China → GM, Customer Service Center → Deputy GM, Marketing Center), each move expanding P&L scope from RMB 30 million to RMB 400 million; concurrently chaired two wholly-owned subsidiaries since 2018.

改动理由：把并列头衔改成"晋升节奏 + 责任范围扩张"，读者能读到成长曲线；`concurrently chaired` 把兼任说清。

## 四、动词分级表

按"角色强度"选词，不要全部用 `Responsible for`：

| 强度 | 动词 | 适用 |
|------|------|------|
| 主导 | Led, Directed, Headed, Chaired, Spearheaded | 有决策权、带团队 |
| 推动 | Drove, Drove adoption of, Championed, Initiated | 推动跨部门落地 |
| 建设 | Built, Designed, Developed, Launched, Established | 从 0 到 1 |
| 优化 | Streamlined, Optimized, Restructured, Automated | 改造既有流程 |
| 交付 | Delivered, Completed, Executed, Implemented | 按计划完成 |
| 分析 | Analyzed, Modeled, Assessed, Quantified | 研究/分析类 |
| 协作 | Coordinated, Partnered with, Liaised with | 无直接权限 |

慎用：`Responsible for`（无强度）、`Participated in`（弱）、`Assisted with`（弱，除非确实只是支持角色）、`Helped`（口语）。

## 五、量化素材从哪来

找不到数字时按这五类去找，几乎总能挖到一两个：

1. **规模**：团队人数、预算金额、客户数、SKU 数、门店数、数据量
2. **效率**：周期缩短百分比、人均产出、自动化替代工时
3. **结果**：营收、毛利、成本节约、转化率、留存率、合格率
4. **范围**：覆盖省市数、跨部门数、跨国时区数、语种数
5. **认可**：排名（前 5%）、获奖等级、被采纳/被引用次数、专利数

真的没有数字时，写可验证的事实：`shipped on schedule`、`adopted by all 6 regional teams`、`cited in the group's annual report`。**绝不编造。**

## 六、逐条自检清单

- [ ] 以动词开头，不用 `I`，不用 `Responsible for` 打头
- [ ] 一条只讲一个意思
- [ ] 有可验证的结果（数字优先）
- [ ] 时态统一：过往经历用过去时，在任职位用现在时
- [ ] 无副词修饰（`very / greatly / highly / successfully`）
- [ ] 不超过两行
- [ ] 我能就这条讲 60 秒英文，并接住 2 个追问
