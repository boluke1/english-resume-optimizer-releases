# 语言规范与校对

四层检查，从文体到格式，逐层过。跳层会留错。

## 第一层：文体（Register）

简历是**书面文体**，不接受口语与非正式表达。

| 错误类型 | 不合格 | 合格 |
|----------|--------|------|
| 口语动词 | Got about 1 mn revenue | Generated approximately USD 1 million in revenue |
| 缩写 | I've won, don't, it's, we're | 全部展开，或改写为动词开头 |
| 第一人称 | I managed a team of 8 | Managed a team of 8 |
| 完成时混用 | I've won three champions | Won three championships (2021–2022) |
| 夸张副词 | very, greatly, highly, successfully, extremely | 删除，用数据 |
| 模糊量词 | many, several, a lot of, various | 具体数字 |
| 中式表达 | learn knowledge, open the computer, grasp the market | acquire knowledge, turn on the computer, capture the market |

补充高频中式用法修正：

- `do a research` → `conduct research`
- `make a survey` → `conduct a survey`
- `improve the efficiency` → `improve efficiency`（不可数不加冠词）
- `according to my experience` → `in my experience`
- `in the recent three years` → `in the past three years` / `over the last three years`

## 第二层：拼写（Spelling）

定稿前必做，且要用"只改错、不改意思"的提示词，避免 AI 顺手重写：

> Please help me proofread the following paragraph. Fix spelling, punctuation and grammar only. Do not change my meaning or add content. List every change you made with the reason.

重点排查：
- 英式/美式混用（`organise/organize`、`programme/program`、`centre/center`）——全文统一，投美版用美式，投欧版用英式。
- 专有名词大小写：`Peking University`、`United Nations`、`Python`、`Trados`。
- 学校、公司、奖项的官方英文名——必须查官网，不要自行翻译。
- 音近错词：`principle/principal`、`complement/compliment`、`affect/effect`、`personal/personnel`。

## 第三层：语法（Grammar）

三个高频失分点，逐条查：

### 1. 词性（Part of Speech）

常见词的名词与动词形式混用是中式简历第一错因。

| 名词 | 动词 | 形容词 |
|------|------|--------|
| analysis | analyze | analytical |
| management | manage | managerial |
| development | develop | developmental |
| growth | grow | growing |
| implementation | implement | implementable |
| improvement | improve | improved |

错误示例：`Responsible for the management of team` → `Managed a team of 8`；`In charge of analysis the data` → `Analyzed 2.4 million transaction records`。

### 2. 时态（Tense）

| 场景 | 时态 | 示例 |
|------|------|------|
| 已结束的经历 | 一般过去时 | `Led the migration in 2023.` |
| 已完成但影响延续 | 现在完成时 | `Have reduced onboarding time by 40% since 2022.`（简历中少用，多见于正文段落） |
| 仍在持续的职责 | 现在进行/现在完成进行 | `Currently leading...` / `Have been leading...` |
| 在任职位 | 一般现在时 | `Manage a team of 12 across 3 regions.` |

规则：**同一条经历内部的时态必须统一**；跨经历可以不同（旧经历过去时，现职现在时）。不要在同一行里 `Led... and managing...` 混用。

### 3. 平行结构（Parallelism）

`and / or` 连接的成分必须同形。

- ❌ `designing, building and operation of systems`
- ✅ `designing, building and operating systems`
- ❌ `responsible for budget, hiring and to train staff`
- ✅ `responsible for budgeting, hiring and training staff`

列表内所有要点也要平行：都以动词开头，或都以名词短语开头，不混。

## 第四层：格式（Format）

| 项 | 规范 |
|----|------|
| 日期 | 美式 `Oct. 1980`、`06/2015`；欧式 `Oct 1980`、`06/2015`；区间用 en dash：`2015.06–2016.05` |
| 数字 | 1–9 拼写，10 以上用数字；金额带币种 `RMB 3.2 million` / `USD 1 million`；百分比带基数 `from 46% to 21%` |
| 姓名 | 姓全大写 + 名 + 括号英文名：`ZHANG Hongyan (David)` |
| 电话 | 带国家码：`+86 138 1100 0011`；座机带区号：`+8610 6275 3456` |
| 邮箱 | 姓名拼音，不用昵称与生日数字 |
| 标点 | 英文标点；条目末尾不加句号（全句成段时加）；不用中文顿号、书名号 |
| 缩进 | 要点统一用 `–` 或 `•`，层级不超过两级 |
| 字体 | 全文一种字体（如 Calibri / Times New Roman），字号一致 |

## 校对输出格式

```
| # | 位置 | 原文 | 问题类型 | 修正 | 说明 |
|---|------|------|----------|------|------|
| 1 | Exp.2 第1条 | Got about 1 mn revenue | 文体/单位 | Generated approximately USD 1 million in revenue | 口语动词 + 币种缺失 |
```

无法判断的项（缺年份、缺数字、专有名词待核）单独列"待用户确认"，不要替用户填。
